
Synthetic noisy graph-alignment benchmark.

Number of instances:
    500

Parameters:
    n_values      = [30, 50]
    p_values      = [0.15, 0.3]
    noise_values  = [0.0, 0.05, 0.1, 0.2, 0.3]
    seed_ids      = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    noise_model   = resample

Each .npz file contains:
    A               : adjacency matrix of graph A, shape (n,n), entries 0/1
    B               : noisy permuted adjacency matrix of graph B, shape (n,n), entries 0/1
    B_clean         : clean permuted copy of A before noise, for debugging only
    pi_true         : ground-truth permutation, for evaluation only
    n               : number of vertices
    p               : Erdős-Rényi edge probability
    noise           : noise level
    noise_model     : resample or flip
    generation_seed : random seed used to generate the instance
    seed_id         : small seed index within each parameter setting

Permutation convention:
    pi[i] = a means vertex i in graph A corresponds to vertex a in graph B.

Clean graph convention:
    B_clean[pi_true[i], pi_true[j]] = A[i, j].

Given a proposed permutation pi, align B to A's vertex order by:
    B_aligned = B[np.ix_(pi, pi)]

Default edge-overlap score:
    S(pi) = sum_{i<j} A[i,j] * B[pi[i], pi[j]]

Accuracy, for evaluation only:
    accuracy = mean(pi_hat == pi_true)

Important:
    The algorithm should use only A and B.
    The fields pi_true and B_clean are for evaluation/debugging only.
